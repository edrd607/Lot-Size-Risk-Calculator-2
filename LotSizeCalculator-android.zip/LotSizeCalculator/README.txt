Lot Size Calculator - Android project

Option A: Android Studio (computer)
  1. Unzip, then File > Open this folder in Android Studio.
  2. Wait for Gradle sync to finish (accept any prompt to download Gradle/SDK).
  3. Build > Build App Bundle(s) / APK(s) > Build APK(s).
  4. The APK is at app/build/outputs/apk/debug/app-debug.apk.

Option B: GitHub (no Android Studio needed)
  1. Create a new GitHub repository and upload everything in this folder,
     keeping the folder structure (including .github/workflows).
  2. Open the Actions tab; the "Build APK" workflow runs automatically.
  3. When it finishes, download "LotSize-apk" from the run's Artifacts.

Installing on your phone: open the APK and allow "Install unknown apps"
for your browser or file manager when Android asks.
